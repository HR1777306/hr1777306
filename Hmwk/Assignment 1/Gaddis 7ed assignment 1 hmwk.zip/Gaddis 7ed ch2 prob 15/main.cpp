/* 
 * File:   main.cpp
 * Author: Hugo Romero
 *purpose:Write a program that displays a triangle 
 * Created on June 29, 2014, 12:33 PM
 */
//system libraries
#include <iostream> input output library

using namespace std;

//user defined libraries

//Global constants

//Function prototypes

/*
 * 
 */
//execution begins here
int main(int argc, char** argv) {
cout << "\t \t \t \t *\n";
cout << "\t \t \t \t***\n";
cout << "\t \t \t       *****\n";
cout << "\t \t \t      *******\n";


   return 0;
}

