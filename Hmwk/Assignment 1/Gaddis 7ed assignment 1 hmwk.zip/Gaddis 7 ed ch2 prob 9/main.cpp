/* 
 * File:   main.cpp
 * Author: Hugo Romero
 * Purpose: Use the size of function
 * Created on June 30, 2014, 1:06 PM
 */
//System level libraries
#include <iostream>

using namespace std;

//User defined libraries

//Global constants

//Function prototypes
/*
 * 
 */
//execution begins here
int main(int argc, char** argv) {
    sizeof(char);
    sizeof(int);
    sizeof(float);
    sizeof(double);
cout<<"size of int = "<< sizeof(int)<<endl;
cout<<"size of char = "<< sizeof(char)<<endl;
cout<<"size of float = "<< sizeof(float)<<endl;
cout<<"size of double = "<<sizeof(double)<<endl;
    return 0;
}

