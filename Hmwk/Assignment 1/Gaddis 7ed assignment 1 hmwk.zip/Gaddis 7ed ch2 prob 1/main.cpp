/* 
 * File:   main.cpp
 * Author: Hugo Romero
 * Purpose: Write a program that stores the integers 62 and 99 in variables, stores the sum of these two in a variable named total.
 * Created on June 29, 2014, 1:18 PM
 */
//System level libraries
#include <iostream> //input output library

using namespace std;
//user defined libraries

//Global constants

//Function prototypes
/*
 * 
 */
//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int a = 65;
    int b = 99;
    int total = a + b;
    cout<<"Total = "<<total<< endl;
    
    return 0;
}