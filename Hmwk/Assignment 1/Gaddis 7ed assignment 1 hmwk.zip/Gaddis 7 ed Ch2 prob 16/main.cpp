/* 
 * File:   main.cpp
 * Author: Hugo Romero
 *Purpose:Write a program that displays a diamond on the console output
 * Created on June 29, 2014, 12:56 PM
 */
//System level libraries
#include <iostream> input output libraries

using namespace std;
//user defined libraries

//User defined libraries

//Global constants

//Function Prototypes

/*
 * 
 */
//Execution begins here
int main(int argc, char** argv) {
    cout << "\t \t \t *\n";
    cout << "\t\t\t***\n";
    cout << " \t \t       *****\n";
    cout << " \t \t      *******\n";
    cout << " \t \t       *****\n";
    cout << "\t\t\t***\n";
    cout << "\t \t \t *\n";
    return 0;  
}

